import { useEffect, useMemo, useState } from "react";
import { api, formatTime } from "@/lib/api";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { motion } from "framer-motion";

const dayMs = 24 * 60 * 60 * 1000;
const startOfMonth = (d) => new Date(d.getFullYear(), d.getMonth(), 1);
const endOfMonth = (d) => new Date(d.getFullYear(), d.getMonth() + 1, 0);
const sameDay = (a, b) =>
  a.getFullYear() === b.getFullYear() &&
  a.getMonth() === b.getMonth() &&
  a.getDate() === b.getDate();

export default function CalendarPage() {
  const [cursor, setCursor] = useState(startOfMonth(new Date()));
  const [fronting, setFronting] = useState([]);
  const [journal, setJournal] = useState([]);
  const [selected, setSelected] = useState(new Date());

  const load = async () => {
    const [f, j] = await Promise.all([
      api.get("/fronting/history?limit=1000"),
      api.get("/journal"),
    ]);
    setFronting(f.data);
    setJournal(j.data);
  };
  useEffect(() => {
    load();
  }, []);

  const cells = useMemo(() => {
    const start = startOfMonth(cursor);
    const end = endOfMonth(cursor);
    const firstWeekday = start.getDay(); // 0=Sun
    const days = [];
    // padding before
    for (let i = 0; i < firstWeekday; i++) days.push(null);
    for (let d = 1; d <= end.getDate(); d++) {
      days.push(new Date(cursor.getFullYear(), cursor.getMonth(), d));
    }
    return days;
  }, [cursor]);

  const eventsByDay = useMemo(() => {
    const map = new Map();
    const add = (d, evt) => {
      const key = `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
      if (!map.has(key)) map.set(key, { fronts: [], journals: [] });
      map.get(key)[evt.kind].push(evt);
    };
    fronting.forEach((f) => {
      const start = new Date(f.started_at);
      const end = f.ended_at ? new Date(f.ended_at) : new Date();
      const cur = new Date(start.getFullYear(), start.getMonth(), start.getDate());
      while (cur <= end) {
        add(cur, { kind: "fronts", color: f.alter_color, name: f.alter_name, ...f });
        cur.setTime(cur.getTime() + dayMs);
      }
    });
    journal.forEach((j) => {
      const d = new Date(j.created_at);
      add(d, { kind: "journals", ...j });
    });
    return map;
  }, [fronting, journal]);

  const dayKey = (d) => `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
  const selectedEvents = eventsByDay.get(dayKey(selected));

  return (
    <div className="space-y-10" data-testid="calendar-page">
      <header className="flex items-end justify-between flex-wrap gap-4">
        <div>
          <span className="label-eyebrow">a month in your system</span>
          <h1 className="font-serif text-5xl font-light mt-3">Calendar</h1>
        </div>
        <div className="flex items-center gap-2">
          <button
            data-testid="cal-prev"
            onClick={() =>
              setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))
            }
            className="btn-ghost !p-2"
          >
            <ChevronLeft size={16} />
          </button>
          <span className="font-serif text-2xl px-3 min-w-[12rem] text-center">
            {cursor.toLocaleString(undefined, {
              month: "long",
              year: "numeric",
            })}
          </span>
          <button
            data-testid="cal-next"
            onClick={() =>
              setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))
            }
            className="btn-ghost !p-2"
          >
            <ChevronRight size={16} />
          </button>
        </div>
      </header>

      <div className="grid grid-cols-7 gap-2 sm:gap-3" data-testid="calendar-grid">
        {["S", "M", "T", "W", "T", "F", "S"].map((d, i) => (
          <div
            key={i}
            className="text-center text-xs tracking-[0.2em] text-[color:var(--text-disabled)]"
          >
            {d}
          </div>
        ))}
        {cells.map((d, i) => {
          if (!d)
            return <div key={i} className="aspect-square" data-testid="cal-empty-cell" />;
          const evs = eventsByDay.get(dayKey(d));
          const isToday = sameDay(d, new Date());
          const isSelected = sameDay(d, selected);
          return (
            <motion.button
              key={i}
              whileHover={{ y: -2 }}
              data-testid={`cal-day-${d.getDate()}`}
              onClick={() => setSelected(d)}
              className="aspect-square rounded-2xl p-2 sm:p-3 text-left flex flex-col justify-between transition-all"
              style={{
                background: isSelected
                  ? "rgba(124,144,130,0.15)"
                  : "var(--bg-surface)",
                border: `1px solid ${
                  isSelected
                    ? "var(--brand-primary)"
                    : isToday
                    ? "rgba(212,163,115,0.4)"
                    : "var(--border-default)"
                }`,
              }}
            >
              <span
                className="font-serif text-lg sm:text-xl"
                style={{
                  color: isToday
                    ? "var(--brand-highlight)"
                    : "var(--text-primary)",
                }}
              >
                {d.getDate()}
              </span>
              <div className="flex flex-wrap gap-1">
                {evs?.fronts
                  .filter(
                    (f, idx, arr) =>
                      arr.findIndex((x) => x.alter_id === f.alter_id) === idx
                  )
                  .slice(0, 4)
                  .map((f, idx) => (
                    <span
                      key={idx}
                      className="h-2 w-2 rounded-full"
                      style={{ background: f.color }}
                    />
                  ))}
                {evs?.journals.length > 0 && (
                  <span
                    className="h-2 w-2 rounded-full"
                    style={{ background: "var(--brand-accent)" }}
                    title="journal"
                  />
                )}
              </div>
            </motion.button>
          );
        })}
      </div>

      <section className="surface p-7" data-testid="calendar-day-detail">
        <span className="label-eyebrow">
          {selected.toLocaleString(undefined, {
            weekday: "long",
            month: "long",
            day: "numeric",
          })}
        </span>
        {!selectedEvents ? (
          <p className="font-serif text-2xl text-[color:var(--text-secondary)] mt-4">
            Nothing logged this day.
          </p>
        ) : (
          <div className="mt-6 space-y-6">
            {selectedEvents.fronts.length > 0 && (
              <div>
                <p className="text-sm text-[color:var(--text-secondary)] mb-3">
                  Fronted this day
                </p>
                <div className="flex flex-wrap gap-2">
                  {Array.from(
                    new Map(
                      selectedEvents.fronts.map((f) => [f.alter_id, f])
                    ).values()
                  ).map((f) => (
                    <span
                      key={f.alter_id}
                      className="flex items-center gap-2 px-3 py-1.5 rounded-full"
                      style={{
                        background: f.color + "22",
                        color: f.color,
                      }}
                    >
                      <span className="dot" style={{ background: f.color }} />
                      {f.name}
                    </span>
                  ))}
                </div>
              </div>
            )}
            {selectedEvents.journals.length > 0 && (
              <div>
                <p className="text-sm text-[color:var(--text-secondary)] mb-3">
                  Journal entries
                </p>
                <div className="space-y-3">
                  {selectedEvents.journals.map((j) => (
                    <div
                      key={j.id}
                      className="surface-flat p-4"
                      data-testid={`cal-journal-${j.id}`}
                    >
                      <p className="text-xs text-[color:var(--text-disabled)]">
                        {formatTime(j.created_at)}{" "}
                        {j.mood && (
                          <span className="text-[color:var(--brand-primary)]">
                            · {j.mood}
                          </span>
                        )}
                      </p>
                      {j.title && (
                        <p className="font-serif text-lg mt-1">{j.title}</p>
                      )}
                      <p className="text-sm mt-1 whitespace-pre-wrap">
                        {j.body}
                      </p>
                      {j.symptoms?.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 mt-2">
                          {j.symptoms.map((s) => (
                            <span
                              key={s}
                              className="text-xs px-2 py-0.5 rounded-full"
                              style={{
                                color: "var(--brand-accent)",
                                background: "rgba(169,111,93,0.15)",
                              }}
                            >
                              {s}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </section>
    </div>
  );
}
