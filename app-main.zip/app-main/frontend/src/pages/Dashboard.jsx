import { useEffect, useState } from "react";
import { api, formatTime, relativeTime } from "@/lib/api";
import { ArrowRightLeft, Plus, Sparkles, Square } from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";

export default function Dashboard() {
  const [alters, setAlters] = useState([]);
  const [current, setCurrent] = useState([]);
  const [history, setHistory] = useState([]);
  const [showSwitch, setShowSwitch] = useState(false);
  const [switchNote, setSwitchNote] = useState("");
  const [selectedAlter, setSelectedAlter] = useState("");
  const [coFront, setCoFront] = useState(false);

  const load = async () => {
    const [a, c, h] = await Promise.all([
      api.get("/alters"),
      api.get("/fronting/current"),
      api.get("/fronting/history?limit=15"),
    ]);
    setAlters(a.data);
    setCurrent(c.data);
    setHistory(h.data);
  };

  useEffect(() => {
    load();
  }, []);

  const submitSwitch = async (alterIdOverride) => {
    const target =
      typeof alterIdOverride === "string" ? alterIdOverride : selectedAlter;
    if (!target) {
      toast.error("Pick who's fronting");
      return;
    }
    const path = coFront ? "/fronting/cofront" : "/fronting/switch";
    await api.post(path, { alter_id: target, note: switchNote });
    toast.success(coFront ? "Added to front" : "Switch logged");
    setShowSwitch(false);
    setSwitchNote("");
    setSelectedAlter("");
    setCoFront(false);
    load();
  };

  // unique alters fronted recently, excluding ones currently at the front
  const recentAlters = (() => {
    const currentIds = new Set(current.map((c) => c.alter_id));
    const seen = new Set();
    const out = [];
    for (const h of history) {
      if (currentIds.has(h.alter_id)) continue;
      if (seen.has(h.alter_id)) continue;
      seen.add(h.alter_id);
      out.push(h);
      if (out.length >= 5) break;
    }
    return out;
  })();

  const endFront = async (id) => {
    await api.post(`/fronting/end/${id}`);
    load();
  };

  return (
    <div className="space-y-14" data-testid="dashboard-page">
      {/* Current fronter hero */}
      <section className="relative overflow-hidden surface p-8 sm:p-12 glow-warm">
        <span className="label-eyebrow">currently fronting</span>
        {current.length === 0 ? (
          <div className="mt-6">
            <h1 className="font-serif text-4xl sm:text-5xl font-light text-[color:var(--text-secondary)]">
              No one logged yet
            </h1>
            <p className="mt-3 text-[color:var(--text-secondary)]">
              Tap below to log who's at the front right now.
            </p>
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="mt-6 space-y-4"
          >
            {current.map((c) => (
              <div
                key={c.id}
                className="flex items-center justify-between gap-4"
                data-testid={`current-fronter-${c.alter_id}`}
              >
                <div className="flex items-center gap-4">
                  <span
                    className="h-14 w-14 rounded-full flex items-center justify-center font-serif text-2xl"
                    style={{
                      background: c.alter_color + "22",
                      color: c.alter_color,
                      border: `1.5px solid ${c.alter_color}66`,
                    }}
                  >
                    {c.alter_name?.[0] || "?"}
                  </span>
                  <div>
                    <h1 className="font-serif text-4xl sm:text-5xl font-light leading-none">
                      {c.alter_name}
                    </h1>
                    <p className="text-sm text-[color:var(--text-secondary)] mt-2">
                      since {formatTime(c.started_at)} · {relativeTime(c.started_at)}
                    </p>
                  </div>
                </div>
                <button
                  data-testid={`end-front-${c.alter_id}`}
                  onClick={() => endFront(c.id)}
                  className="btn-ghost !py-2"
                  title="End"
                >
                  <Square size={14} /> end
                </button>
              </div>
            ))}
          </motion.div>
        )}

        <div className="mt-10 flex flex-wrap gap-3">
          <button
            data-testid="log-switch-button"
            onClick={() => setShowSwitch((s) => !s)}
            className="btn-primary"
          >
            <ArrowRightLeft size={16} /> Log a switch
          </button>
          {alters.length === 0 && (
            <a className="btn-ghost" href="/headmates" data-testid="add-alters-cta">
              <Plus size={15} /> Add your first headmate
            </a>
          )}
        </div>

        {recentAlters.length > 0 && (
          <div className="mt-8" data-testid="quick-switch-back">
            <p className="label-eyebrow mb-3">switch back to</p>
            <div className="flex flex-wrap gap-2">
              {recentAlters.map((r) => (
                <button
                  key={r.id}
                  data-testid={`quick-switch-${r.alter_id}`}
                  onClick={() => submitSwitch(r.alter_id)}
                  className="flex items-center gap-2 px-4 py-2 rounded-full border transition-all"
                  style={{
                    borderColor: "var(--border-default)",
                    background: "var(--bg-flat)",
                  }}
                >
                  <span
                    className="dot"
                    style={{ background: r.alter_color }}
                  />
                  <span className="text-sm">{r.alter_name}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {showSwitch && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            className="mt-8 surface-flat p-6 space-y-4"
            data-testid="switch-form"
          >
            <div>
              <label className="label-eyebrow">who's at the front</label>
              <div className="mt-3 flex flex-wrap gap-2">
                {alters.length === 0 && (
                  <p className="text-sm text-[color:var(--text-secondary)]">
                    Add a headmate first.
                  </p>
                )}
                {alters.map((a) => (
                  <button
                    key={a.id}
                    data-testid={`pick-alter-${a.id}`}
                    onClick={() => setSelectedAlter(a.id)}
                    className="flex items-center gap-2 px-4 py-2 rounded-full transition-all border"
                    style={{
                      borderColor:
                        selectedAlter === a.id ? a.color : "var(--border-default)",
                      background:
                        selectedAlter === a.id
                          ? a.color + "22"
                          : "var(--bg-flat)",
                    }}
                  >
                    <span
                      className="dot"
                      style={{ background: a.color }}
                    />
                    <span>{a.name}</span>
                  </button>
                ))}
              </div>
            </div>
            <textarea
              data-testid="switch-note-input"
              placeholder="A small note about this switch (optional)"
              className="input-cozy"
              value={switchNote}
              onChange={(e) => setSwitchNote(e.target.value)}
            />
            <label className="flex items-center gap-2 text-sm text-[color:var(--text-secondary)]">
              <input
                data-testid="cofront-checkbox"
                type="checkbox"
                checked={coFront}
                onChange={(e) => setCoFront(e.target.checked)}
              />
              Add as co-fronter (don't end current)
            </label>
            <div className="flex gap-3">
              <button
                data-testid="submit-switch-button"
                className="btn-primary"
                onClick={() => submitSwitch()}
              >
                <Sparkles size={15} /> Save switch
              </button>
              <button
                className="btn-ghost"
                onClick={() => setShowSwitch(false)}
              >
                Cancel
              </button>
            </div>
          </motion.div>
        )}
      </section>

      {/* History timeline */}
      <section>
        <div className="flex items-baseline justify-between mb-6">
          <h2 className="font-serif text-3xl font-medium">Recent switches</h2>
          <span className="text-sm text-[color:var(--text-secondary)]">
            {history.length} entries
          </span>
        </div>

        {history.length === 0 ? (
          <div className="surface-flat p-8 text-[color:var(--text-secondary)]">
            Your fronting history will appear here.
          </div>
        ) : (
          <div
            className="border-l-2 pl-8 ml-4 relative space-y-7"
            style={{ borderColor: "rgba(163,160,153,0.12)" }}
            data-testid="history-timeline"
          >
            {history.map((h) => (
              <div key={h.id} className="relative">
                <span
                  className="absolute -left-[42px] top-1.5 h-5 w-5 rounded-full border-4"
                  style={{
                    background: h.alter_color,
                    borderColor: "var(--bg-main)",
                  }}
                />
                <div className="flex items-baseline justify-between gap-4 flex-wrap">
                  <p className="font-serif text-2xl">{h.alter_name}</p>
                  <p className="text-xs text-[color:var(--text-disabled)]">
                    {formatTime(h.started_at)}
                  </p>
                </div>
                {h.note && (
                  <p className="text-sm text-[color:var(--text-secondary)] mt-1">
                    {h.note}
                  </p>
                )}
                {h.ended_at && (
                  <p className="text-xs text-[color:var(--text-disabled)] mt-1">
                    ended {relativeTime(h.ended_at)}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
