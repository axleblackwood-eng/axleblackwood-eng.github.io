import { useAuth } from "@/context/AuthContext";
import { Navigate } from "react-router-dom";
import { Loader2, Moon, Users, BookOpen, Shield } from "lucide-react";

const AUTH_BG =
  "https://images.unsplash.com/photo-1511207538754-e8555f2bc187?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1NTJ8MHwxfHNlYXJjaHw0fHxjb3p5JTIwZGFyayUyMGFlc3RoZXRpYyUyMGJhY2tncm91bmR8ZW58MHx8fHwxNzgxMzY3NDE2fDA&ixlib=rb-4.1.0&q=85";

export default function Landing() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="animate-spin text-[color:var(--text-secondary)]" />
      </div>
    );
  }
  if (user) return <Navigate to="/dashboard" replace />;

  const login = () => {
    // REMINDER: DO NOT HARDCODE THE URL, OR ADD ANY FALLBACKS OR REDIRECT URLS, THIS BREAKS THE AUTH
    const redirectUrl = window.location.origin + "/dashboard";
    window.location.href = `https://auth.emergentagent.com/?redirect=${encodeURIComponent(
      redirectUrl
    )}`;
  };

  return (
    <div className="min-h-screen relative overflow-hidden" data-testid="landing-page">
      <div
        className="absolute inset-0 -z-10"
        style={{
          backgroundImage: `linear-gradient(rgba(22,22,21,0.78), rgba(22,22,21,0.95)), url(${AUTH_BG})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />

      <header className="px-6 sm:px-10 py-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Moon className="text-[color:var(--brand-highlight)]" size={20} />
          <span className="font-serif text-2xl">pluralhaven</span>
        </div>
        <button
          data-testid="login-button-nav"
          onClick={login}
          className="btn-ghost"
        >
          Sign in
        </button>
      </header>

      <main className="px-6 sm:px-10 pt-16 sm:pt-24 max-w-5xl mx-auto">
        <span className="label-eyebrow">a quiet place for plural systems</span>
        <h1 className="font-serif text-5xl sm:text-7xl font-light mt-6 leading-[1.05] tracking-tight">
          A cozy journal for you,
          <br />
          <em className="text-[color:var(--brand-highlight)] not-italic font-normal">
            and everyone inside.
          </em>
        </h1>

        <p className="mt-8 text-lg text-[color:var(--text-secondary)] max-w-2xl leading-relaxed">
          Track who's fronting, jot symptoms, share gentle notes between alters,
          and offer trusted friends a window in — with privacy buckets you control.
        </p>

        <div className="mt-12 flex flex-wrap gap-4">
          <button
            data-testid="login-button-main"
            onClick={login}
            className="btn-primary text-base"
          >
            Continue with Google
          </button>
          <a
            href="#features"
            className="btn-ghost"
            data-testid="learn-more-link"
          >
            See what it does
          </a>
        </div>

        <section
          id="features"
          className="mt-28 grid sm:grid-cols-3 gap-6"
          data-testid="features-grid"
        >
          {[
            {
              icon: Users,
              title: "Headmates & switches",
              body: "Log who's fronting in a tap. Keep a soft history of every switch, with notes if you want.",
            },
            {
              icon: BookOpen,
              title: "Symptoms & journal",
              body: "Drop quick mood entries, symptom tags, or longer letters between alters.",
            },
            {
              icon: Shield,
              title: "Privacy buckets",
              body: "Pick exactly which alters and details each trusted friend can see. Share a private link.",
            },
          ].map((f, i) => (
            <div key={i} className="surface p-7">
              <f.icon size={20} className="text-[color:var(--brand-primary)]" />
              <h3 className="font-serif text-2xl mt-5">{f.title}</h3>
              <p className="text-[color:var(--text-secondary)] mt-3 leading-relaxed">
                {f.body}
              </p>
            </div>
          ))}
        </section>

        <p className="mt-24 mb-12 text-sm text-[color:var(--text-disabled)]">
          Made with care. Not a medical tool, but a safe place to notice yourselves.
        </p>
      </main>
    </div>
  );
}
