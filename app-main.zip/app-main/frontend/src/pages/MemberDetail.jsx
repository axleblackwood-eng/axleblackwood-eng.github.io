import { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { api, formatTime, relativeTime } from "@/lib/api";
import { ArrowLeft, Pencil, ArrowRightLeft, Sparkles } from "lucide-react";
import { toast } from "sonner";
import Markdown from "@/components/Markdown";
import { motion } from "framer-motion";

export default function MemberDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [data, setData] = useState(null);

  const load = async () => {
    try {
      const res = await api.get(`/alters/${id}`);
      setData(res.data);
    } catch (e) {
      toast.error("Couldn't load headmate");
      navigate("/headmates", { replace: true });
    }
  };
  useEffect(() => {
    load();
  }, [id]);

  const setFront = async () => {
    await api.post("/fronting/switch", { alter_id: id });
    toast.success("Switched to front");
    load();
  };

  if (!data) return null;
  const a = data.alter;

  return (
    <div className="space-y-10" data-testid={`member-detail-${a.id}`}>
      <button
        data-testid="back-to-headmates"
        onClick={() => navigate("/headmates")}
        className="btn-ghost !text-sm"
      >
        <ArrowLeft size={14} /> All headmates
      </button>

      <motion.section
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className="surface p-8 sm:p-12 relative overflow-hidden glow-warm"
      >
        <div className="flex items-start gap-6 flex-wrap">
          <span
            className="h-24 w-24 rounded-full flex items-center justify-center font-serif text-4xl overflow-hidden"
            style={{
              background: a.color + "22",
              color: a.color,
              border: `2px solid ${a.color}66`,
            }}
          >
            {a.avatar_url ? (
              <img
                src={a.avatar_url.startsWith("/api/") ? `${process.env.REACT_APP_BACKEND_URL}${a.avatar_url}` : a.avatar_url}
                alt={a.name}
                className="h-full w-full object-cover"
              />
            ) : (
              a.name?.[0]
            )}
          </span>
          <div className="flex-1 min-w-[200px]">
            <span className="label-eyebrow">headmate</span>
            <h1 className="font-serif text-5xl sm:text-6xl font-light mt-2 leading-none">
              {a.name}
            </h1>
            <div className="mt-3 flex flex-wrap gap-3 items-center text-sm text-[color:var(--text-secondary)]">
              {a.pronouns && <span>{a.pronouns}</span>}
              {a.role && (
                <span
                  className="px-3 py-1 rounded-full text-xs"
                  style={{ background: a.color + "22", color: a.color }}
                >
                  {a.role}
                </span>
              )}
            </div>
          </div>
          <div className="flex gap-2">
            <button
              data-testid="set-fronting-button"
              onClick={setFront}
              className="btn-primary"
            >
              <ArrowRightLeft size={14} /> Set as fronting
            </button>
            <Link
              to="/headmates"
              state={{ editId: a.id }}
              data-testid="edit-from-detail"
              className="btn-ghost"
            >
              <Pencil size={13} /> Edit
            </Link>
          </div>
        </div>

        {a.description && (
          <div className="mt-10 pt-8 border-t border-white/5">
            <Markdown>{a.description}</Markdown>
          </div>
        )}
      </motion.section>

      <section>
        <div className="flex items-baseline justify-between mb-5">
          <h2 className="font-serif text-3xl font-medium">Recent fronts</h2>
          <Sparkles size={16} className="text-[color:var(--brand-primary)]" />
        </div>
        {data.fronting.length === 0 ? (
          <div className="surface-flat p-6 text-[color:var(--text-secondary)] text-sm">
            No fronting logged for this headmate yet.
          </div>
        ) : (
          <div
            className="border-l-2 pl-7 ml-3 relative space-y-5"
            style={{ borderColor: "rgba(163,160,153,0.12)" }}
          >
            {data.fronting.map((f) => (
              <div key={f.id} className="relative">
                <span
                  className="absolute -left-[36px] top-1.5 h-4 w-4 rounded-full border-4"
                  style={{
                    background: a.color,
                    borderColor: "var(--bg-main)",
                  }}
                />
                <p className="text-sm">{formatTime(f.started_at)}</p>
                <p className="text-xs text-[color:var(--text-disabled)]">
                  {f.ended_at ? `ended ${relativeTime(f.ended_at)}` : "still fronting"}
                </p>
                {f.note && (
                  <p className="text-sm text-[color:var(--text-secondary)] mt-1">
                    {f.note}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}
      </section>

      <section>
        <h2 className="font-serif text-3xl font-medium mb-5">
          Notes from {a.name}
        </h2>
        {data.journal.length === 0 ? (
          <div className="surface-flat p-6 text-[color:var(--text-secondary)] text-sm">
            No journal entries written by {a.name} yet.
          </div>
        ) : (
          <div className="space-y-4">
            {data.journal.map((j) => (
              <article key={j.id} className="surface-flat p-5">
                <p className="text-xs text-[color:var(--text-disabled)]">
                  {formatTime(j.created_at)}
                  {j.mood && (
                    <span className="text-[color:var(--brand-primary)]"> · {j.mood}</span>
                  )}
                </p>
                {j.title && <h3 className="font-serif text-xl mt-2">{j.title}</h3>}
                <p className="mt-2 whitespace-pre-wrap leading-relaxed">{j.body}</p>
              </article>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
