import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import { Save, Eye, Edit3 } from "lucide-react";
import { toast } from "sonner";
import Markdown from "@/components/Markdown";

export default function Profile() {
  const { user, setUser } = useAuth();
  const [form, setForm] = useState({
    display_name: "",
    system_name: "",
    pronouns: "",
    bio: "",
  });
  const [preview, setPreview] = useState(false);

  useEffect(() => {
    if (user) {
      setForm({
        display_name: user.display_name || "",
        system_name: user.system_name || "",
        pronouns: user.pronouns || "",
        bio: user.bio || "",
      });
    }
  }, [user]);

  const save = async () => {
    const res = await api.put("/profile", form);
    setUser({ ...user, ...res.data });
    toast.success("Profile saved");
  };

  return (
    <div className="space-y-10" data-testid="profile-page">
      <header>
        <span className="label-eyebrow">your system's home page</span>
        <h1 className="font-serif text-5xl font-light mt-3">Profile</h1>
        <p className="text-[color:var(--text-secondary)] mt-3 max-w-xl">
          How your system shows up to friends with access. Bio supports
          markdown <em>and</em> safe HTML.
        </p>
      </header>

      <section className="surface p-7 space-y-5">
        <div className="flex items-center gap-4">
          {user?.picture && (
            <img
              src={user.picture}
              alt=""
              className="h-16 w-16 rounded-full border border-white/10"
            />
          )}
          <div>
            <p className="font-serif text-2xl">{user?.name}</p>
            <p className="text-sm text-[color:var(--text-secondary)]">
              {user?.email}
            </p>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="label-eyebrow">system name</label>
            <input
              data-testid="profile-system-name"
              className="input-cozy mt-2"
              placeholder="e.g. the moonlit garden"
              value={form.system_name}
              onChange={(e) =>
                setForm({ ...form, system_name: e.target.value })
              }
            />
          </div>
          <div>
            <label className="label-eyebrow">display name</label>
            <input
              data-testid="profile-display-name"
              className="input-cozy mt-2"
              value={form.display_name}
              onChange={(e) =>
                setForm({ ...form, display_name: e.target.value })
              }
            />
          </div>
          <div>
            <label className="label-eyebrow">system pronouns</label>
            <input
              data-testid="profile-pronouns"
              className="input-cozy mt-2"
              placeholder="we/us"
              value={form.pronouns}
              onChange={(e) => setForm({ ...form, pronouns: e.target.value })}
            />
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between">
            <label className="label-eyebrow">about your system (md / html)</label>
            <button
              data-testid="toggle-bio-preview"
              onClick={() => setPreview((p) => !p)}
              className="btn-ghost !py-1.5 !text-xs"
            >
              {preview ? <Edit3 size={12} /> : <Eye size={12} />}
              {preview ? "edit" : "preview"}
            </button>
          </div>
          {preview ? (
            <div
              className="mt-2 input-cozy min-h-[12rem]"
              data-testid="bio-preview"
            >
              <Markdown>{form.bio || "*Nothing yet.*"}</Markdown>
            </div>
          ) : (
            <textarea
              data-testid="profile-bio-input"
              rows={10}
              className="input-cozy mt-2 font-mono text-sm"
              placeholder={`# We are the Moonlit Garden\n\nA system of **6**. <mark>protector</mark>, host, and four littles.\n\n- [x] we're tired today\n- [ ] we're okay`}
              value={form.bio}
              onChange={(e) => setForm({ ...form, bio: e.target.value })}
            />
          )}
        </div>

        <div className="flex gap-3">
          <button
            data-testid="save-profile-button"
            className="btn-primary"
            onClick={save}
          >
            <Save size={14} /> Save profile
          </button>
        </div>
      </section>
    </div>
  );
}
