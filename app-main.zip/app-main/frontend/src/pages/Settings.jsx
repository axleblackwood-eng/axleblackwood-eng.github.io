import { useState } from "react";
import { api } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import { Download, Trash2, LogOut, ExternalLink, Users } from "lucide-react";
import { toast } from "sonner";
import { Link } from "react-router-dom";

export default function Settings() {
  const { user, logout } = useAuth();
  const [confirming, setConfirming] = useState(false);

  const exportData = async () => {
    const res = await api.get("/export");
    const blob = new Blob([JSON.stringify(res.data, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `pluralhaven-export-${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
    toast.success("Export downloaded");
  };

  const deleteAccount = async () => {
    if (!confirming) {
      setConfirming(true);
      return;
    }
    await api.delete("/account");
    toast.success("Account deleted");
    window.location.href = "/";
  };

  return (
    <div className="space-y-10 max-w-3xl" data-testid="settings-page">
      <header>
        <span className="label-eyebrow">your space</span>
        <h1 className="font-serif text-5xl font-light mt-3">Settings</h1>
      </header>

      <section className="surface-flat p-6 flex items-center justify-between flex-wrap gap-3">
        <div>
          <p className="font-serif text-xl">Profile & system bio</p>
          <p className="text-sm text-[color:var(--text-secondary)] mt-1">
            Edit how your system shows up to friends.
          </p>
        </div>
        <Link
          to="/profile"
          className="btn-ghost"
          data-testid="goto-profile-link"
        >
          <ExternalLink size={13} /> Open profile
        </Link>
      </section>

      <section className="surface-flat p-6 flex items-center justify-between flex-wrap gap-3">
        <div>
          <p className="font-serif text-xl">Systems supporting me</p>
          <p className="text-sm text-[color:var(--text-secondary)] mt-1">
            See the systems that have invited you in.
          </p>
        </div>
        <Link
          to="/supporting"
          className="btn-ghost"
          data-testid="goto-supporting-link"
        >
          <Users size={13} /> Open
        </Link>
      </section>

      <section className="surface-flat p-6 flex items-center justify-between flex-wrap gap-3">
        <div>
          <p className="font-serif text-xl">Export your data</p>
          <p className="text-sm text-[color:var(--text-secondary)] mt-1">
            A JSON dump of headmates, fronting, journal, and friend buckets.
          </p>
        </div>
        <button
          data-testid="export-data-button"
          onClick={exportData}
          className="btn-ghost"
        >
          <Download size={13} /> Download
        </button>
      </section>

      <section className="surface-flat p-6 flex items-center justify-between flex-wrap gap-3">
        <div>
          <p className="font-serif text-xl">Account</p>
          <p className="text-sm text-[color:var(--text-secondary)] mt-1">
            Signed in as {user?.email}
          </p>
        </div>
        <button
          data-testid="logout-settings-button"
          onClick={logout}
          className="btn-ghost"
        >
          <LogOut size={13} /> Sign out
        </button>
      </section>

      <section
        className="surface-flat p-6 space-y-3"
        style={{ borderColor: "rgba(140,74,74,0.3)" }}
      >
        <p className="font-serif text-xl text-[color:var(--brand-danger)]">
          Danger zone
        </p>
        <p className="text-sm text-[color:var(--text-secondary)]">
          Delete your account and all data — headmates, fronting history,
          journal entries, friend buckets. This can't be undone.
        </p>
        <button
          data-testid="delete-account-button"
          onClick={deleteAccount}
          className="btn-ghost"
          style={{
            color: "var(--brand-danger)",
            borderColor: "rgba(140,74,74,0.4)",
          }}
        >
          <Trash2 size={13} />
          {confirming ? "Click again to confirm" : "Delete account"}
        </button>
      </section>
    </div>
  );
}
