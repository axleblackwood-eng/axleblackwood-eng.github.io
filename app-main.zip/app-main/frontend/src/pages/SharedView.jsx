import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { api, formatTime, relativeTime } from "@/lib/api";
import { Moon, Loader2 } from "lucide-react";
import Markdown from "@/components/Markdown";

export default function SharedView() {
  const { token } = useParams();
  const [data, setData] = useState(null);
  const [err, setErr] = useState(null);

  useEffect(() => {
    api
      .get(`/share/${token}`)
      .then((r) => setData(r.data))
      .catch(() => setErr(true));
  }, [token]);

  if (err) {
    return (
      <div
        className="min-h-screen flex items-center justify-center p-8"
        data-testid="share-error"
      >
        <p className="text-[color:var(--text-secondary)]">
          This link isn't valid anymore.
        </p>
      </div>
    );
  }
  if (!data) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="animate-spin text-[color:var(--text-secondary)]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen" data-testid="shared-view">
      <header className="max-w-3xl mx-auto px-6 sm:px-8 pt-10 pb-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Moon className="text-[color:var(--brand-highlight)]" size={18} />
          <span className="font-serif text-xl">pluralhaven</span>
        </div>
        <span className="text-xs text-[color:var(--text-disabled)]">
          shared with {data.friend_name}
        </span>
      </header>

      <main className="max-w-3xl mx-auto px-6 sm:px-8 pb-20 space-y-12">
        <section>
          <span className="label-eyebrow">{data.system_name}'s system</span>
          <h1 className="font-serif text-5xl font-light mt-3">
            Hi {data.friend_name}.
          </h1>
          {data.system_bio && (
            <div className="mt-6 surface-flat p-6" data-testid="shared-system-bio">
              <Markdown>{data.system_bio}</Markdown>
            </div>
          )}
        </section>

        {data.settings.show_current_fronter && (
          <section className="surface p-8">
            <span className="label-eyebrow">currently fronting</span>
            {data.current_fronters.length === 0 ? (
              <p className="font-serif text-3xl text-[color:var(--text-secondary)] mt-4">
                Nothing logged right now.
              </p>
            ) : (
              <div className="mt-5 space-y-4">
                {data.current_fronters.map((c) => (
                  <div
                    key={c.alter_id}
                    className="flex items-center gap-4"
                    data-testid={`share-fronter-${c.alter_id}`}
                  >
                    <span
                      className="h-12 w-12 rounded-full flex items-center justify-center font-serif text-xl"
                      style={{
                        background: c.alter_color + "22",
                        color: c.alter_color,
                        border: `1.5px solid ${c.alter_color}66`,
                      }}
                    >
                      {c.alter_name?.[0]}
                    </span>
                    <div>
                      <p className="font-serif text-3xl">{c.alter_name}</p>
                      <p className="text-xs text-[color:var(--text-secondary)] mt-1">
                        since {formatTime(c.started_at)} ·{" "}
                        {relativeTime(c.started_at)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        )}

        <section>
          <span className="label-eyebrow">headmates you can see</span>
          <div className="grid sm:grid-cols-2 gap-4 mt-5">
            {data.alters.length === 0 && (
              <p className="text-[color:var(--text-secondary)]">
                None shared yet.
              </p>
            )}
            {data.alters.map((a) => (
              <div
                key={a.id}
                className="surface-flat p-5"
                data-testid={`share-alter-${a.id}`}
              >
                <div className="flex items-center gap-3">
                  <span
                    className="h-10 w-10 rounded-full flex items-center justify-center font-serif text-lg"
                    style={{
                      background: a.color + "22",
                      color: a.color,
                      border: `1.5px solid ${a.color}66`,
                    }}
                  >
                    {a.name?.[0]}
                  </span>
                  <div>
                    <p className="font-serif text-xl">{a.name}</p>
                    {a.pronouns && (
                      <p className="text-xs text-[color:var(--text-secondary)]">
                        {a.pronouns}
                      </p>
                    )}
                  </div>
                </div>
                {a.role && (
                  <span
                    className="inline-block mt-3 text-xs px-2.5 py-1 rounded-full"
                    style={{ background: a.color + "22", color: a.color }}
                  >
                    {a.role}
                  </span>
                )}
                {a.description && (
                  <div className="text-sm text-[color:var(--text-secondary)] mt-3 leading-relaxed">
                    <Markdown>{a.description}</Markdown>
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>

        {data.settings.show_journal && data.journal.length > 0 && (
          <section>
            <span className="label-eyebrow">shared notes</span>
            <div className="space-y-4 mt-5">
              {data.journal.map((j, i) => (
                <article
                  key={i}
                  className="surface-flat p-5"
                  data-testid={`share-journal-${i}`}
                >
                  <p className="text-xs text-[color:var(--text-disabled)]">
                    {formatTime(j.created_at)}{" "}
                    {j.mood && (
                      <span className="text-[color:var(--brand-primary)]">
                        · {j.mood}
                      </span>
                    )}
                  </p>
                  {j.title && (
                    <h3 className="font-serif text-xl mt-2">{j.title}</h3>
                  )}
                  <p className="mt-2 whitespace-pre-wrap leading-relaxed text-[color:var(--text-primary)]/90">
                    {j.body}
                  </p>
                </article>
              ))}
            </div>
          </section>
        )}

        <p className="text-xs text-[color:var(--text-disabled)] text-center pt-6">
          A private window shared by {data.system_name} on pluralhaven.
        </p>
      </main>
    </div>
  );
}
