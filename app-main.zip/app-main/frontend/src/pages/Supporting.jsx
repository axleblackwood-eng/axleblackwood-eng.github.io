import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { Heart, ExternalLink } from "lucide-react";
import { Link } from "react-router-dom";

export default function Supporting() {
  const [items, setItems] = useState([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    api.get("/supporting").then((r) => {
      setItems(r.data);
      setLoaded(true);
    });
  }, []);

  return (
    <div className="space-y-10" data-testid="supporting-page">
      <header>
        <span className="label-eyebrow">the people you support</span>
        <h1 className="font-serif text-5xl font-light mt-3">Supporting</h1>
        <p className="text-[color:var(--text-secondary)] mt-3 max-w-xl">
          Systems that have invited you in. Tap a card to see who's fronting
          and the parts of their system they've shared.
        </p>
      </header>

      {!loaded ? null : items.length === 0 ? (
        <div className="surface-flat p-10 text-[color:var(--text-secondary)]">
          <p>
            No invitations yet. When a friend creates a privacy bucket with
            your email, their system will show up here.
          </p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 gap-5" data-testid="supporting-grid">
          {items.map((s) => (
            <Link
              key={s.id}
              to={`/share/${s.share_token}`}
              data-testid={`supporting-card-${s.id}`}
              className="surface p-6 hover:-translate-y-1 transition-transform flex items-center gap-4"
            >
              {s.system_picture ? (
                <img
                  src={s.system_picture}
                  alt=""
                  className="h-14 w-14 rounded-full border border-white/10"
                />
              ) : (
                <span
                  className="h-14 w-14 rounded-full flex items-center justify-center font-serif text-2xl"
                  style={{
                    background: "rgba(124,144,130,0.2)",
                    color: "var(--brand-primary)",
                  }}
                >
                  <Heart size={20} />
                </span>
              )}
              <div className="flex-1">
                <p className="font-serif text-2xl">{s.system_name}</p>
                {s.friend_label && (
                  <p className="text-sm text-[color:var(--text-secondary)] mt-1">
                    you're tagged as: {s.friend_label}
                  </p>
                )}
              </div>
              <ExternalLink
                size={16}
                className="text-[color:var(--text-secondary)]"
              />
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
