# pluralhaven — PRD

## Original Problem Statement
"an app exactly like simply plural so me and my friends can track my symptoms of DID and log whos fronting with ease"

## User Choices
- Each person has their own private account
- Google Sign-In (Emergent-managed)
- Core features: all (alters/headmates, fronting tracker, symptom/mood journal, shared notes, friend trusted view)
- Visual: dark/cozy aesthetic ("Nocturnal Earth" palette, Cormorant Garamond + Manrope)
- Privacy: per-friend privacy buckets + Simply Plural JSON import

## User Personas
- **System holder** — primary user with DID, manages alters, logs switches, journals symptoms.
- **Alters within the system** — write/read journal entries when shared.
- **Trusted friend/partner/therapist** — receives a private share link; only sees what's enabled in their bucket.

## Core Requirements (static)
1. Private Google-auth account per user.
2. Manage alters (name, pronouns, role, color, description, avatar).
3. Log fronting events — switch (ends previous) or co-front (adds another); end specific entries.
4. Journal entries with mood, tags/symptoms, alter attribution, shared/private toggle.
5. Friend privacy buckets — choose visible alters + toggles (current fronter, pronouns, roles, descriptions, journal). Each friend gets a unique share token.
6. Public /share/:token read-only view (no auth needed) honoring the bucket.
7. Simply Plural JSON import for alters.
8. Full data export (JSON).
9. Cozy dark UI throughout.

## Implementation Status
### v1 — 2026-02-13
- Auth (Google OAuth), Alters CRUD, Fronting tracker, Journal, Friend privacy buckets, Share link, Simply Plural import, Export.

### v2 — 2026-02-13 (this iteration)
- **Calendar view** (`/calendar`) — month grid with colored dots per day (fronts + journal); click a day → its events.
- **Avatar upload** via Emergent object storage (`/api/upload/avatar`, served at `/api/files/{path}`).
- **Quick switch-back chips** on Dashboard from recent history.
- **Journal filters** by mood, alter, symptom.
- **Member detail page** (`/headmates/:id`) — clickable cards open a profile w/ markdown-rendered description, recent fronts timeline, journal entries by that alter, and a one-tap "Set as fronting".
- **Settings page** (`/settings`) — profile shortcut, supporting link, JSON export, sign out, delete-account.
- **User profile** (`/profile`) — system name, display name, pronouns, **markdown + safe HTML bio** with live preview. Bio appears in the friend share view.
- **Member profiles support markdown + HTML** (description field).
- **Friend self-serve login**: Friend records have an email; signed-in friends see invitations under `/supporting`.
- Markdown sanitised via `rehype-sanitize` with an allowlist (incl. `<mark>`, `<details>`, `<kbd>`).
- Tested 100% backend + 100% frontend.

## Backlog
### P1
- Modal-based delete confirmation (better a11y) instead of two-click.
- Storage object cleanup on account deletion.
- Optional access control on `/api/files/{path}` if private files are ever stored.
- Lower-case emails on write + query for `/api/supporting` invitations.
### P2
- Daily check-in reminders (push / email).
- Symptom & switch frequency charts.
- Multi-language support.
- PWA install prompt.
- Friend dashboard aggregating multiple supported systems at once (currently lists & links out).

## Next Tasks
- Gather feedback on first real-use.
- Consider adding image uploads inside markdown bio/description (currently URL only).
